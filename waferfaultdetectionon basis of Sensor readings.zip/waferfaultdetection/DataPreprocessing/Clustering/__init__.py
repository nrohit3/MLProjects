import kneed
from FileOperations import FileMethods
from application_logging import App_logger
from sklearn.cluster import KMeans
from kneed import KneeLocator
class KmeansClustering:
    def __init__(self,file_object):
        self.file_object=file_object
        self.logger=App_logger()

    def elbowplot(self,data):
        self.logger.log(self.file_object,'Clustering Started!!')
        wcss=[]
        try:
            for i in range(1,11):
                kmeans=KMeans(n_clusters=i,random_state=42)
                kmeans.fit(data)
                wcss.append(kmeans.inertia_)

            self.kn=kneed.KneeLocator(range(1,11),wcss,curve='convex',direction='decreasing')
            return self.kn.knee

        except Exception as e:
            self.logger.log(self.file_object,'Error Occurred: %s'%e)

    def create_clusters(self,data,number_of_clusters):
        try:
            self.logger.log(self.file_object,'Entered the create_clusters method of the KMeansClustering class')
            self.kmeans=KMeans(n_clusters=number_of_clusters)
            self.kmeans.fit(data)
            y_kmeans=self.kmeans.predict(data)
            data['clusters']=y_kmeans
            filemethods=FileMethods.File_Operations(self.file_object)
            self.savemodel=filemethods.save_model(self.kmeans,'kmeans')
            print(self.savemodel)
            return data

        except Exception as e:
            self.logger.log(self.file_object,'Exception raised in cluster assignment : %s'%e)




