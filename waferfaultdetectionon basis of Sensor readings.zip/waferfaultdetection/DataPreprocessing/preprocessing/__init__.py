from application_logging import App_logger
import pandas as pd
from sklearn.impute import KNNImputer

class Preprocessor:
    def __init__(self,file_object):
        self.logger = App_logger()
        self.fileobj = file_object

    def remove_columns(self,data,columns):
        self.logger.log(self.fileobj,'Remove column {} operation started '.format(columns))
        try:
            useful_data=data.drop(labels=columns,axis=1)
            self.logger.log(self.fileobj,'Column removal successful')
            return useful_data
        except Exception as e:
            self.logger.log(self.fileobj, 'Exception raised : %s'%e)

    def seperate_lable_features(self,data,label_column_name):
        try:
            self.logger.log(self.fileobj,'Seperate predictor from data into X and y')
            X=data.drop(labels=label_column_name,axis=1)
            y=data[label_column_name]
            return X,y
        except Exception as e:
            self.logger.log(self.fileobj, 'Exception raised : %s' % e)

    def isnull_present(self,df):
        isnullind=0
        try:
            data=pd.DataFrame(df.isnull().sum(axis=1))
            self.logger.log(self.fileobj,'Check if any null values in tables')
            df1 = pd.DataFrame(data=df.isnull().sum(axis=0)).reset_index()
            df1.rename(columns={'index': 'cols', 0: 'count of nulls'}, inplace=True)
            if df1[df1['count of nulls'] != 0]['cols'].values.size != 0:
                isnullind=1
            return isnullind
        except Exception as e:
            self.logger.log(self.fileobj,'Exception raised :%s'%e)

    def impute_missing_values(self,data):
        self.logger.log(self.fileobj,'Imputation of Missing values Started!!')
        try:
            imputer=KNNImputer(n_neighbors=3)
            data_array=imputer.fit_transform(data)
            df=pd.DataFrame(data=data_array,columns=data.columns)
            self.logger.log(self.fileobj, 'Imputation completed!!')
            return(df)
        except Exception as e:
            self.logger.log(self.fileobj, 'Exception raised :%s' % e)

    def getcols_with_0_std_dev(self,data):
        self.logger.log(self.fileobj, 'Checking columns with 0 std dev!!')
        list_with_0_std=[]
        df=data.select_dtypes(exclude='object')
        for i in df:
            if df[i].std()==0:
                list_with_0_std.append(i)
        return list_with_0_std
