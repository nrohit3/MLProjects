import os.path
import pickle
from application_logging import App_logger
import shutil
class File_Operations:
    def __init__(self,file_object):
        self.file_object=file_object
        self.logging=App_logger()
        self.model_directory='models/'

    def save_model(self,model,filename):
        try:
            self.logging.log(self.file_object,'Model Save Operation Begins!!')
            path=os.path.join(self.model_directory,filename)
            if os.path.isdir(path):
                shutil.rmtree(self.model_directory)
                os.makedirs(path)
            else:
               # os.mkdir(self.model_directory)
                os.makedirs(path)

            with open(path+'/'+filename+'.sav','wb') as f:
                pickle.dump(model,f)
            self.logging.log(self.file_object,'model written to file')
            return 'success'

        except Exception as e:
            self.logging.log(self.file_object,'Exception raised in saving model : %s'%e)
            return 'Failed'

    def load_model(self,filename):
        self.logging.log(self.file_object,'Entered the load_model method of the File_Operation class')
        try:
            with open (self.model_directory+'/'+filename+'/'+filename+'.sav','rb') as f:
                return pickle.load(f)

        except Exception as e:
            self.logging.log(self.file_object,'Exception raised : %s' %e)

    def find_correct_model_file(self,clusterno):

        self.clusterno=clusterno
        self.folder_name=self.model_directory
        self.list_of_model_files=[]
        self.list_of_files=os.listdir(self.folder_name)

        for self.file in self.list_of_files:
            if str(clusterno) in self.file:
                self.modelname=self.file

        return self.modelname




