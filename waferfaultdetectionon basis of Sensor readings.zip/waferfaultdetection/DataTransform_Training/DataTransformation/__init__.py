import os

import pandas as pd
from datetime import datetime
from application_logging import App_logger
import os

class dataTransform:
    def __init__(self):
        self.goodDataPath='Training_Raw_files_validated/Good_Raw'
        self.goodDataPathPred = 'Prediction_Raw_files_validated/Good_Raw'
        self.logger=App_logger()

    def replaceMissingWithNull(self):
        file =open('Training_Logs/dataTransformLog.txt','a+')
        try:
            self.logger.log(file,'Data Transformation started !!')
            onlyfile=[f for f in os.listdir(self.goodDataPath)]
            for i in onlyfile:
                csv=pd.read_csv(self.goodDataPath+'/'+i)
                csv.fillna('NULL',inplace=True)
                csv['Wafer']=csv['Wafer'].str[6:]
                csv.to_csv(self.goodDataPath+'/'+i,index=False)
                self.logger.log(file,'Transformed %s Successfully'%i)

        except Exception as e:
            self.logger.log(file,'File Transformation failed : %s'%str(e))
            file.close()

        file.close()


    def replacePredMissingWithNull(self):
        file =open('Prediction_Logs/dataTransformLog.txt','a+')
        try:
            self.logger.log(file,'Data Transformation started !!')
            onlyfile=[f for f in os.listdir(self.goodDataPathPred)]
            for i in onlyfile:
                csv=pd.read_csv(self.goodDataPathPred+'/'+i)
                csv.fillna('NULL',inplace=True)
                csv['Wafer']=csv['Wafer'].str[6:]
                csv.to_csv(self.goodDataPathPred+'/'+i,index=False)
                self.logger.log(file,'Transformed %s Successfully'%i)

        except Exception as e:
            self.logger.log(file,'File Transformation failed : %s'%str(e))
            file.close()

        file.close()
