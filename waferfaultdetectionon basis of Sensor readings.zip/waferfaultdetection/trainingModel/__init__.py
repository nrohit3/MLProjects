from application_logging import App_logger
from DataLoader import DataGetter
from DataPreprocessing import preprocessing
from DataPreprocessing import Clustering
from sklearn.model_selection import train_test_split
from tuner import ModelFinder
from FileOperations import FileMethods
import pandas as pd
class trainModel:
    def __init__(self):
        self.log_writer=App_logger()
        self.file_writer=open("Training_Logs/Model_Training_logs.txt",'a+')

    def trainingModel(self):
        self.log_writer.log(self.file_writer,'Start of Training')
        data_getter=DataGetter(self.file_writer)
        data=data_getter.get_data()
        preprocess=preprocessing.Preprocessor(self.file_writer)
        data=preprocess.remove_columns(data,'Wafer')
        X,y=preprocess.seperate_lable_features(data,'Output')
        isnullind=preprocess.isnull_present(X)
        if isnullind==1:
            X=preprocess.impute_missing_values(X)

        cols_to_drop=preprocess.getcols_with_0_std_dev(X)
        print(cols_to_drop)
        X=preprocess.remove_columns(X,cols_to_drop)
        #print(X)
        X.to_csv('DataFileToModel.csv',index=False, header=True)
        kmeans=Clustering.KmeansClustering(self.file_writer)
        no_of_clusters=kmeans.elbowplot(X)
        X=kmeans.create_clusters(data=X,number_of_clusters=no_of_clusters)
        X['Labels']=y
        #print(X.head())

        list_of_clusters=X['clusters'].unique()

        for i in list_of_clusters:
            cluster_data=X[X['clusters']==i]
            features=cluster_data.drop(['clusters','Labels'],axis=1)
            label=cluster_data['Labels']

            X_train,X_test,y_train,y_test=train_test_split(features,label,train_size=2/3,random_state=355)
            self.mf=ModelFinder(file_object=self.file_writer)
            bestmodelname,bestmodel=self.mf.get_best_model(train_x=X_train,train_y=y_train,test_x=X_test,test_y=y_test)

            fileops=FileMethods.File_Operations(self.file_writer)
            save_model=fileops.save_model(bestmodel,bestmodelname+str(i))

            print(save_model)

            self.log_writer.log(file_object=self.file_writer,log_message='Successful end of training')
        self.file_writer.close()





