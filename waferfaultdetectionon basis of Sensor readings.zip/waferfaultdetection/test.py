import pandas as pd
import flask
from flask import request, render_template,Flask
from flask import Response
import numpy as np
from trainingModel import trainModel
from training_Validation_Insertion import train_validation
from PredictionValidationInsertion import PredictionValidation
from predictFromModel import prediction
from flask_cors import CORS, cross_origin
import json
from wsgiref import simple_server
import os

app=Flask(__name__)
CORS(app)
@app.route("/", methods=['GET'])
@cross_origin()
def home():
    return render_template('templates/index.html')

@app.route("/predict", methods=['POST'])
@cross_origin()
def predictRouteClient():
    try:
        if request.json is not None:
            path = request.json['filepath']

            predvalobj = PredictionValidation.pred_validation(path)
            predvalobj.pred_validation()



            pred = prediction(path) #object initialization

            # predicting for dataset present in database
            path,json_predictions = pred.predictionFromModel()
            return Response("Prediction File created at !!!"  +str(path) +'and few of the predictions are '+str(json.loads(json_predictions) ))
        elif request.form is not None:
            path = request.form['filepath']

            predvalobj = PredictionValidation.pred_validation(path)
            predvalobj.pred_validation()


            pred = prediction(path) #object initialization

            # predicting for dataset present in database
            path,json_predictions = pred.predictionFromModel()
            return Response("Prediction File created at !!!"  +str(path) +'and few of the predictions are '+str(json.loads(json_predictions) ))
        else:
            print('Nothing Matched')
    except ValueError:
        return Response("Error Occurred! %s" %ValueError)
    except KeyError:
        return Response("Error Occurred! %s" %KeyError)
    except Exception as e:
        return Response("Error Occurred! %s" %e)

    @app.route("/train", methods=['POST'])
    @cross_origin()
    def trainRouteClient():

        try:
            if request.json['folderPath'] is not None:
                path = request.json['folderPath']

                train_valObj = train_validation(path)  # object initialization

                train_valObj.train_validation()  # calling the training_validation function

                trainModelObj = trainModel()  # object initialization
                trainModelObj.trainingModel()  # training the model for the files in the table


        except ValueError:

            return Response("Error Occurred! %s" % ValueError)

        except KeyError:

            return Response("Error Occurred! %s" % KeyError)

        except Exception as e:

            return Response("Error Occurred! %s" % e)
        return Response("Training successfull!!")

    port = int(os.getenv("PORT", 5000))
    if __name__ == "__main__":
        host = '0.0.0.0'
        # port = 5000
        httpd = simple_server.make_server(host, port, app)
        # print("Serving on %s %d" % (host, port))
        httpd.serve_forever()
"""
path = r'C:\Users\Rohit\OneDrive\Desktop\Python DS UPGRAD\DS Class\Proj sql py\practice\waferfaultdetection\Training_Batch_Files'
train_valobj = train_validation(path)
train_valobj.train_validation()

trainModelObj=trainModel()
trainModelObj.trainingModel()

pred_path=r'C:\Users\Rohit\OneDrive\Desktop\Python DS UPGRAD\DS Class\Proj sql py\practice\waferfaultdetection\Prediction_Batch_Files'
predvalobj=PredictionValidation.pred_validation(pred_path)
predvalobj.pred_validation()

pred=prediction(path)
pred.PredictionFromModel()
"""

