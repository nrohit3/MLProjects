import os
from datetime import datetime
from Training_Raw_data_validation.rawValidation import Raw_Data_validation
from DataTransform_Training.DataTransformation import dataTransform
from application_logging import App_logger
import pandas as pd
from DataTypeValidation_Insertion_Training.DataTypeValidation import dBOperation

class train_validation:
    def __init__(self,path):
        self.raw_data=Raw_Data_validation(path)
        self.data_transform=dataTransform()
        self.log_writer=App_logger()
        self.file_object=open("Training_Logs/Training_Main_Log.txt", 'a+')
        self.dBOperation=dBOperation()

    def train_validation(self):
        self.log_writer.log(self.file_object ,'Start of Validation of files')
        LengthOfDateStampInFile, LengthOfTimeStampInFile, column_names, noofcolumns =self.raw_data.valuesfromschema()
        regex=self.raw_data.manualRegexCreation()
        self.raw_data.validationFileNameRaw(regex,LengthOfDateStampInFile, LengthOfTimeStampInFile)
        self.raw_data.validateColumnLength(noofcolumns)
        self.raw_data.validateMissingValuesInWholeColumn()
        self.log_writer.log(self.file_object, "Raw Data Validation Complete!!")

        self.log_writer.log(self.file_object, "Starting Data Transforamtion!!")
        self.log_writer.log(self.file_object, "DataTransformation Completed!!!")
        self.data_transform.replaceMissingWithNull()
        self.dBOperation.createTableDb(host='localhost',user='root',passwd='Feb2018a',schema='r1',column_names=column_names)
        self.dBOperation.insertIntoTableGoodData(host='localhost',user='root',passwd='Feb2018a')
        self.dBOperation.selectingDatafromtableintocsv(host='localhost',user='root',passwd='Feb2018a')

        self.raw_data.deleteExistingGoodDataTrainingFolder()
        self.raw_data.moveBadFilesToArchiveBad()
        self.dBOperation.selectingDatafromtableintocsv(host='localhost',user='root',passwd='Feb2018a')
        self.file_object.close()







