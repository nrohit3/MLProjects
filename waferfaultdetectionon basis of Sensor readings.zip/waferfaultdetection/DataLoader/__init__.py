import pandas as pd

from application_logging import App_logger


class DataGetter :
    def __init__(self,file_object):
        self.training_file='Training_Raw_files_validated/Training_FileFromDB/InputFile.csv'
        self.file_writer=file_object
        self.logger=App_logger()
        self.prediction_file='Prediction_Raw_Files_Validated/Training_FileFromDB/InputFile.csv'


    def get_data(self):
        self.logger.log(self.file_writer,'Entered Get data function')
        try:
            self.data=pd.read_csv(self.training_file)
            self.logger.log(self.file_writer,'Created DataFrame of input file')
            return self.data
        except Exception as e:
            self.logger.log(self.file_writer,'Exception occurred: %s'%e)

    def get_data_pred(self):
        self.logger.log(self.file_writer,'Entered Get data function')
        try:
            self.data=pd.read_csv(self.prediction_file)
            self.logger.log(self.file_writer,'Created DataFrame of input file of prediction')
            return self.data
        except Exception as e:
            self.logger.log(self.file_writer,'Exception occurred: %s'%e)