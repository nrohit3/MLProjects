from application_logging import App_logger
from Prediction_Raw_Data_Validation import PredictionDataValidation
from DataTransform_Training import DataTransformation
from DataTypeValidation_Insertion_Prediction import DataTypeValidation
import pandas as pd

class pred_validation:
    def __init__(self,path):
        self.logger=App_logger()
        self.rawdata=PredictionDataValidation.predictiondatavalidation(path)
        self.dataTransform=DataTransformation.dataTransform()
        self.dbOperation=DataTypeValidation.dBOperation()
        self.file_object = open("Prediction_Logs/Prediction_Log.txt", 'a+')

    def pred_validation(self):
        self.logger.log(self.file_object,'Start of file validation for prediction')
        LengthOfDateStampInFile,LengthOfTimeStampInFile,column_names,noofcolumns =self.rawdata.valuesfromschema()
        print([LengthOfDateStampInFile,LengthOfTimeStampInFile,column_names,noofcolumns])
        regex=self.rawdata.manualRegexCreation()
        print(regex)
        self.rawdata.validationFileNameRaw(regex=regex,LengthOfDateStampInFile=LengthOfDateStampInFile,LengthOfTimeStampInFile=LengthOfTimeStampInFile)
        self.rawdata.validateColumnLength(noofcolumns)
        self.rawdata.validateMissingValuesInWholeColumn()
        self.logger.log(self.file_object,'Validation of Prediction file is completed')

        self.logger.log(self.file_object,'Data Transformation Started')
        self.dataTransform.replacePredMissingWithNull()
        dv=DataTypeValidation.dBOperation()

        dv.createTableDb(host='localhost',user='root',passwd='Feb2018a',schema='r1pred',column_names=column_names)
        dv.insertIntoTableGoodData(host='localhost',user='root',passwd='Feb2018a')
        dv.selectingDatafromtableintocsv(host='localhost',user='root',passwd='Feb2018a')

        self.rawdata.deleteExistingGoodDataTrainingFolder()
        self.rawdata.moveBadFilesToArchiveBad()









