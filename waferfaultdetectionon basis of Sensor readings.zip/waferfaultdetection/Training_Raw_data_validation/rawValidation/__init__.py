import re

from application_logging import App_logger
import json
import os
import shutil
from datetime import datetime
import pandas as pd

class Raw_Data_validation:
    def __init__(self,path):
        self.Batch_Directory=path
        self.schema_path='schema_training.json'
        self.logger=App_logger()

    def valuesfromschema(self):
        try:
            with open(self.schema_path,'r') as f:
                dic=json.load(f)
                f.close()
            pattern=dic['SampleFileName']
            LengthOfDateStampInFile=dic["LengthOfDateStampInFile"]
            LengthOfTimeStampInFile=dic["LengthOfTimeStampInFile"]
            column_names=dic["ColName"]
            NumberofColumns=dic["NumberofColumns"]
            file = open('Training_Logs/valuesfromSchemaValidationLog.txt', 'a+')
            msg="LengthOfDateStampInFile ::%s" %LengthOfDateStampInFile + "LengthOfTimeStampInFile :: %s" %LengthOfTimeStampInFile +"\t " + "NumberofColumns:: %s" % NumberofColumns + "\n"
            self.logger.log(file,msg)
            return LengthOfDateStampInFile, LengthOfTimeStampInFile, column_names, NumberofColumns

        except Exception as e:
            file=open('Training_Logs/valuesfromSchemaValidationLog.txt','a+')
            self.logger.log(file,'Exception Raised :: %s' %str(e))
            file.close()


    def manualRegexCreation(self):

        regex = "['wafer']+['\_'']+[\d_]+[\d]+\.csv"
        return regex

    def createDirectoryForGoodBadRawData(self):
        try:
            path=os.path.join('Training_Raw_files_validated/','Good_Raw/')
            if not os.path.isdir(path):
                os.mkdir(path)

            path = os.path.join('Training_Raw_files_validated/', 'Bad_Raw/')
            if not os.path.isdir(path
                                 ):
                os.mkdir(path)

        except Exception as e:
            file=open('Training_Logs/GeneralLog.txt','a+' )
            self.log_writer.log(file,'Exception raised for Good/Bad directory creation : %s'%str(e))
            file.close()

    def deleteExistingGoodDataTrainingFolder(self):
        path='Training_Raw_files_validated/'
        try:
            if os.path.isdir(path+'Good_Raw/'):
                shutil.rmtree(path+'Good_Raw/')
                file=open('Training_Logs/GeneralLog.txt','a+')
                self.logger.log(file,'Good_Raw deleted Successfully!!')
                file.close()
        except Exception as e:
            file = open('Training_Logs/GeneralLog.txt', 'a+')
            self.logger.log(file, 'Exception Raised in Good Direct deletion :%s!!'%str(e))
            file.close()

    def deleteExistingBadDataTrainingFolder(self):
        path='Training_Raw_files_validated/'
        try:
            if os.path.isdir(path+'Bad_Raw/'):
                shutil.rmtree(path+'Bad_Raw/')
                file=open('Training_Logs/GeneralLog.txt','a+')
                self.logger.log(file,'Bad_Raw deleted Successfully!!')
                file.close()
        except Exception as e:
            file = open('Training_Logs/GeneralLog.txt', 'a+')
            self.logger.log(file, 'Exception Raised in Bad direct deletion:%s!!'%str(e) )
            file.close()

    def moveBadFilesToArchiveBad(self):
        now=datetime.now()
        date=now.date()
        time=now.strftime('%H%M%S')
        try:
            source='Training_Raw_files_validated/Bad_Raw'
            if os.path.isdir(source):
                path="TrainingArchiveBadData"
                if not os.path.isdir(path):
                    os.mkdir(path)
                dest="TrainingArchiveBadData/BadData_ " + str(date) + "_" + str(time)
                if not os.path.isdir(dest):
                    os.mkdir(dest)
                files =os.listdir(source)
                for f in files:
                    if f not in os.listdir(dest):
                        shutil.move(source+f,dest)
                file=open('Training_Logs/GeneralLog.txt','a+')
                self.logger.log(file,'Bad Files Archived in {}'.format(dest))
                file.close()
        except Exception as e:
            file = open('Training_Logs/GeneralLog.txt', 'a+')
            self.logger.log(file, 'exception raised in Bad file Archive : %s'%str(e))
            file.close()

    def validationFileNameRaw(self,regex,LengthOfDateStampInFile,LengthOfTimeStampInFile):
        self.deleteExistingBadDataTrainingFolder()
        self.deleteExistingGoodDataTrainingFolder()

        self.createDirectoryForGoodBadRawData()
        onlyfiles=[f for f in os.listdir(self.Batch_Directory)]
        try:
            file=open('Training_Logs/nameValidationLog.txt','a+')
            for filenames in onlyfiles:
                if(re.match(regex,filenames)):
                    splitAtDot=re.split('.csv',filenames)
                    splitAtDot = re.split('_', splitAtDot[0])
                    if(len(splitAtDot[1])==LengthOfDateStampInFile):
                        if len(splitAtDot[2])==LengthOfTimeStampInFile:
                            shutil.copy('Training_Batch_Files/'+filenames,'Training_Raw_files_validated/Good_Raw')
                            self.logger.log(file,'Training files  moved to Training_Raw_files_validated/Good_Raw :%s '%filenames)
                        else:
                            shutil.copy('Training_Batch_Files/' + filenames, 'Training_Raw_files_validated/Bad_Raw')
                            self.logger.log(file, 'Invalid file name !!Training files moved to Training_Raw_files_validated/Bad_Raw %s'%filenames)
                    else:
                         shutil.copy('Training_Batch_Files/' + filenames, 'Training_Raw_files_validated/Bad_Raw')
                         self.logger.log(file, 'Invalid file name !!Training files moved to Training_Raw_files_validated/Bad_Raw %s'%filenames)

                else:
                    shutil.copy('Training_Batch_Files/' + filenames, 'Training_Raw_files_validated/Bad_Raw')
                    self.logger.log(file, 'Invalid file name !!Training files moved to Training_Raw_files_validated/Bad_Raw %s'%filenames)
            file.close()

        except Exception as e:
            file=open('Training_Logs/nameValidationLog.txt')
            self.logger.log(file,'Exception Raised in file name check %s'%str(e))
            file.close()

    def validateColumnLength(self, NumberofColumns):

        try:
            file =open('Training_Logs/columnValidationLog.txt','a+')
            self.logger.log(file,'Column Length Validation started')

            for f in os.listdir('Training_Raw_files_validated/Good_Raw'):
                csv=pd.read_csv(r'Training_Raw_files_validated/Good_Raw/'+f)
                #print(csv.head())
                if csv.shape[1]==NumberofColumns:
                    #print(csv.shape)
                    pass
                else:
                    #print(csv.shape)
                    shutil.move('Training_Raw_files_validated/Good_Raw/'+f,'Training_Raw_files_validated/Bad_Raw/')
                    self.logger.log(file,'File moved to Bad folder as no .of columns is incorrect')
            self.logger.log(file,'Column Length Validation Completed successfully')
            file.close()

        except Exception as e:
            file=open('Training_Logs/columnValidationLog.txt','a+')
            self.logger.log(file,'Exception Raised in col lenth Validation %s'%str(e))
            file.close()

    def validateMissingValuesInWholeColumn(self):

        try:
            f=open('Training_Logs\missingValuesInColumns.txt','a+')

            for files in os.listdir('Training_Raw_files_validated\Good_Raw'):
                csv=pd.read_csv(r'Training_Raw_files_validated\Good_Raw\%s'%files)

                count=0
                for i in csv:
                    if(len(csv[i])-csv[i].count()==len(csv[i])):
                        shutil.move('Training_Raw_files_validated\Good_Raw\%s'%files,'Training_Raw_files_validated\Bad_Raw')
                        self.logger.log(f,'file %s moved to Bad folder as one of the column has complete null values'%csv)
                        count+=1
                        break
                if count==0:
                    csv.rename(columns={'Unnamed: 0': 'Wafer'} , inplace=True)
                    csv.to_csv('Training_Raw_files_validated\Good_Raw\%s'%files, index=None, header=True)
                    self.logger.log(f,
                                    'Good file column 1 name corrected to wafer')
            f.close()
        except Exception as e:
            f = open("Training_Logs/missingValuesInColumn.txt", 'a+')
            self.logger.log(f, "Error Occured:: %s" % e)
            f.close()
            raise e









