import pandas as pd
from FileOperations import FileMethods
from DataPreprocessing import preprocessing
from DataLoader import DataGetter
from application_logging import App_logger
from Prediction_Raw_Data_Validation import PredictionDataValidation

class prediction:
    def __init__(self,path):
        self.file_object=open('Prediction_Logs/Prediction_Log.txt','a+')
        self.logger=App_logger()
        if path is not None:
            self.pred_data_val=PredictionDataValidation.predictiondatavalidation(path)

    def PredictionFromModel(self):
        try:
            self.pred_data_val.deletePredictionFile()
            self.logger.log(self.file_object,'Start of Prediction')
            data_getter=DataGetter(file_object=self.file_object)
            data=data_getter.get_data_pred()

            preprocessor=preprocessing.Preprocessor(self.file_object)
            isnullPresent=preprocessor.isnull_present(data)
            if (isnullPresent):
                data=preprocessor.impute_missing_values(data)

            cols_to_drop=preprocessor.getcols_with_0_std_dev(data)
            data=preprocessor.remove_columns(data,cols_to_drop)

            file_loader=FileMethods.File_Operations(self.file_object)
            kmeans=file_loader.load_model('kmeans')

            clusters=kmeans.predict(data.drop(['Wafer'],axis=1))
            data['clusters']=clusters
            clusters=data['clusters'].unique()

            for i in clusters:
                clusterdata=data[data['clusters']==i]
                wafer_names=list(clusterdata['Wafer'])
                clusterdata=clusterdata.drop(['Wafer','clusters'],axis=1)
                model_name=file_loader.find_correct_model_file(i)
                model=file_loader.load_model(model_name)
                result=list(model.predict(clusterdata))
                result=pd.DataFrame(list(zip(wafer_names,result)),columns=['wafer','prediction'])
                path='Prediction_output_file/Predictions.csv'
                result.to_csv(path_or_buf=path,header=True,mode='a+')

            self.logger.log(self.file_object,'End of Prediction')
        except Exception as e:
            self.logger.log(self.file_object,'Exception raised : %s'%e)



