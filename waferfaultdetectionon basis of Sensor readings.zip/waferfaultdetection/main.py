
from trainingModel import trainModel
from training_Validation_Insertion import train_validation
from PredictionValidationInsertion import PredictionValidation
from predictFromModel import prediction


path = r'C:\Users\Rohit\OneDrive\Desktop\Python DS UPGRAD\DS Class\Proj sql py\practice\waferfaultdetection\Training_Batch_Files'
train_valobj = train_validation(path)
train_valobj.train_validation()

trainModelObj=trainModel()
trainModelObj.trainingModel()

pred_path=r'C:\Users\Rohit\OneDrive\Desktop\Python DS UPGRAD\DS Class\Proj sql py\practice\waferfaultdetection\Prediction_Batch_Files'
predvalobj=PredictionValidation.pred_validation(pred_path)
predvalobj.pred_validation()

pred=prediction(path)
pred.PredictionFromModel()


