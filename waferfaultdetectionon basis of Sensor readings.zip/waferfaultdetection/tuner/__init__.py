from application_logging import App_logger
from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.metrics import roc_auc_score,accuracy_score

class ModelFinder:
    def __init__(self,file_object):
        self.file_object=file_object
        self.logger=App_logger()
        self.rfc=RandomForestClassifier()
        self.xgb=XGBClassifier(objective='binary:logistic')

    def get_best_params_for_random_forest(self,train_x,train_y):
        try:
            params={'n_estimators':[10,50,100,130],'criterion':['gini','entropy'],'max_depth':range(2,4,1),'max_features':['auto','log2']}
            model_cv_rf=GridSearchCV(estimator=self.rfc,param_grid=params,cv=5,verbose=3)
            model_cv_rf.fit(train_x,train_y)

            self.criterion=model_cv_rf.best_params_['criterion']
            self.max_depth=model_cv_rf.best_params_['max_depth']
            self.max_features=model_cv_rf.best_params_['max_features']
            self.n_estimators=model_cv_rf.best_params_['n_estimators']

            self.clf=RandomForestClassifier(n_estimators=self.n_estimators,criterion=self.criterion,max_depth=self.max_depth,max_features=self.max_features)
            self.clf.fit(train_x,train_y)
            self.logger.log(file_object=self.file_object,log_message='RFC best params are :' + str(model_cv_rf.best_params_))
            return self.clf

        except Exception as e:
            self.logger.log(file_object=self.file_object,log_message='Exception raised: %s' %e)

    def get_best_params_for_xgboost(self,train_x,train_y):
        try:
            self.params={'learning_rate': [0.5, 0.1, 0.01, 0.001],
                'max_depth': [3, 5, 10, 20],
                'n_estimators': [10, 50, 100, 200]}
            model_cv_XGB=GridSearchCV(estimator=self.xgb,param_grid=self.params,verbose=3,cv=5)
            model_cv_XGB.fit(train_x,train_y)
            self.lr=model_cv_XGB.best_params_['learning_rate']
            self.max_depth=model_cv_XGB.best_params_['max_depth']
            self.n_estimators=model_cv_XGB.best_params_['n_estimators']

            self.xgb=XGBClassifier(learning_rate=self.lr,max_depth=self.max_depth,n_estimators=self.n_estimators)
            self.xgb.fit(train_x,train_y)

            return self.xgb

        except Exception as e:
            self.logger.log(file_object=self.file_object, log_message='Exception raised: %s' % e)

    def get_best_model(self,train_x,train_y,test_x,test_y):
        self.logger.log(file_object=self.file_object,log_message='Entered best model method of model finder class')
        try:
            self.xgboost =self.get_best_params_for_xgboost(train_x,train_y)
            self.y_pred_xg =self.xgboost.predict(test_x)

            if len(test_y.unique()==1):
                xgboost_score=accuracy_score(test_y,self.y_pred_xg)
            else:
                xgboost_score=roc_auc_score(test_y,self.y_pred_xg)

            self.rfc=self.get_best_params_for_random_forest(train_x,train_y)
            self.y_pred_rfc=self.rfc.predict(test_x)

            if len(test_y.unique()==1):
                rfc_score=accuracy_score(test_y,self.y_pred_rfc)
            else:
                rfc_score=roc_auc_score(test_y,self.y_pred_rfc)
            self.logger.log(file_object=self.file_object, log_message='rfc score:{rfc} and xg score:{xgb} '.format(rfc=rfc_score,xgb=xgboost_score))

            if rfc_score>xgboost_score:
                return 'rfc',self.rfc
            else:
                return 'xgboost',self.xgboost
        except Exception as e:
            self.logger.log(file_object=self.file_object, log_message='Exception raised: %s' % str(e))












