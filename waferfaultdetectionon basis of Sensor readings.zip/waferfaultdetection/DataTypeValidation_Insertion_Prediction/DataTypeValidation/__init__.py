import csv
import mysql.connector as conn
import shutil
from application_logging import App_logger
import os
import pandas as pd

class dBOperation:
    def __init__(self):
        self.path = 'Prediction_Database/'
        self.badFilePath = 'Prediction_Raw_files_validated/Bad_Raw'
        self.goodFilePath = 'Prediction_Raw_files_validated/Good_Raw'
        self.logger = App_logger()
        self.i = 0

    def dataBaseConnection(self,host,user,passwd):
        try:
            mydb=conn.connect(host=host,user=user,passwd=passwd,use_pure=True)
            file=open("Prediction_Logs/DbLogs.txt",'a+')
            self.logger.log(file,'DB Opened Successfully!!')
            file.close()
        except Exception as e:
            file=open("Prediction_Logs/DbLogs.txt",'a+')
            self.logger.log(file,'DB Connectivity Issue!!')
            file.close()
        return mydb

    def createschema(self,host,user,passwd,schema):
        con=self.dataBaseConnection(host=host,user=user,passwd=passwd)
        cur=con.cursor(buffered=True)
        query='show databases'
        cur.execute(query)
        schemalist=cur.fetchall()
        j=0
        for i in schemalist:
            for x in i:
                if schema==x:
                    j+=1
        if j==0:
            query='create schema {sc};'.format(sc=schema)
            cur.execute(query)

    def createTableDb(self,host,user,passwd,schema,column_names):
        self.createschema(host=host,user=user,passwd=passwd,schema=schema)
        mydb = self.dataBaseConnection(host=host,user=user,passwd=passwd)
        c = mydb.cursor(buffered=True)
        query1='use {sc};'.format(sc=schema)
        query = "SHOW TABLES where Tables_in_{sc}='Good_Raw_Data'".format(sc=schema)
        #query = 'use r1;select * from r1.adv'
        c.execute(query1)
        c.execute(query)
        #print(c.fetchone())
        if c.fetchone() != None:

            mydb.close()
            file=open("Prediction_Logs/DbLogs.txt",'a+')
            self.logger.log(file,'Table is created/available. DB CLosed!!')
            file.close()
        else:

            for key in column_names.keys():
                type1 = column_names[key]
                #print(key)
                try:

                    q2 = "CREATE TABLE r1pred.Good_Raw_Data (`{cols}` {dty});".format(cols=key, dty=type1)
                    #print(q2)
                    c.execute(q2)
                    # print(c.fetchall())
                    # mydb.commit()
                    file = open("Prediction_Logs/DbLogs.txt", 'a+')
                    self.logger.log(file, 'Table create completed!!')
                    file.close()

                except :
                    q1 = "ALTER TABLE r1pred.Good_Raw_Data ADD COLUMN `{cols}`{dty};".format(cols=key, dty=type1)
                    #print(q1)
                    c.execute(q1)
                    file = open("Prediction_Logs/DbLogs.txt", 'a+')
                    self.logger.log(file, 'Table alter completed!!')
                    file.close()

    def insertIntoTableGoodData(self,host,user,passwd):

        conn=self.dataBaseConnection(host=host,user=user,passwd=passwd)
        c=conn.cursor(buffered=True)
        onlyfiles=[f for f in os.listdir(self.goodFilePath)]
        print(onlyfiles)
        log_file = open('Prediction_Logs/DBInsertLog.txt','a+')
        i=0
        c.execute('Truncate table r1pred.good_raw_data')
        for files in onlyfiles:
            try:

                with open(self.goodFilePath+'/'+files,'r') as f:
                    next (f)
                    reader=csv.reader(f,delimiter='\n')
                    for f1 in enumerate(reader):
                        for list_ in f1[1]:

                            c.execute('Insert into r1pred.good_raw_data values ({val})'.format(val=list_))

                            conn.commit()
                            self.logger.log(log_file,'File written in db')
                            i+=1

            except Exception as e:
                conn.rollback()
                self.logger.log(log_file,'DB insertion failed: %s'%e)
                shutil.move(self.goodFilePath+'/'+files,self.badFilePath)
        print(i)
        conn.close()
        log_file.close()

    def selectingDatafromtableintocsv(self,host,user,passwd):

        conn=self.dataBaseConnection(host=host,user=user,passwd=passwd)
        df=pd.read_sql(sql='select * from r1pred.good_raw_data',con=conn)
#        df.fillna('NULL',inplace=True)
        log_file = open("Prediction_Logs/ExportToCsv.txt", 'a+')
        if not os.path.isdir('Prediction_Raw_files_validated/Prediction_FileFromDB/'):
            os.makedirs('Prediction_Raw_files_validated/Prediction_FileFromDB/')
        df.to_csv(r'Prediction_Raw_files_validated/Prediction_FileFromDB/PredictionFile.csv',index=False, header=True)
        self.logger.log(log_file,'Data inserted into csv from db')
        log_file.close()
        conn.close()





